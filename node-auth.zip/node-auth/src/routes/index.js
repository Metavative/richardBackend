// src/routes/index.js
import { Router } from "express";

import authRoutes from "./authRoutes.js";
import friendRoutes from "./friendroutes.js"; // ⚠️ ensure filename matches exactly
import userRoutes from "./userRoutes.js";
import matchmakingRoutes from "./matchmakingRoutes.js";
import aiCoachRoutes from "./aiCoachRoutes.js";
import challengeRoutes from "./challengeRoutes.js";
import presenceRoutes from "./presenceRoutes.js";

const router = Router();

/**
 * Health check
 * GET /api/health
 */
router.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "LA-TREL Backend",
    time: new Date().toISOString(),
  });
});

/**
 * Auth
 * /api/auth/*
 */
router.use("/auth", authRoutes);

/**
 * Friends
 * /api/friends/*
 */
router.use("/friends", friendRoutes);

/**
 * Users
 * /api/users/*
 */
router.use("/users", userRoutes);

/**
 * Challenges (REST – existing)
 * /api/challenges/*
 */
router.use("/challenges", challengeRoutes);

/**
 * Matchmaking
 * /api/matchmaking/*
 */
router.use("/matchmaking", matchmakingRoutes);

/**
 * AI Coach
 * /api/ai/*
 */
router.use("/ai", aiCoachRoutes);

/**
 * Presence (REST – optional)
 * /api/presence/*
 */
router.use("/presence", presenceRoutes);

export default router;
