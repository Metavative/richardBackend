// src/routes/presenceRoutes.js
import { Router } from "express";
import { presenceStore } from "../stores/presence.store.js";
import { requireAuth } from "../middleware/requireAuth.js";

const router = Router();

/**
 * GET /api/presence/online
 * Returns online snapshot (authed only)
 */
router.get("/online", requireAuth, (_req, res) => {
  return res.json({
    ok: true,
    online: presenceStore.snapshot(),
  });
});

export default router;
