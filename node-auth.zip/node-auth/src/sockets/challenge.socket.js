// src/sockets/challenges.socket.js
import createError from "http-errors";
import Match from "../models/Match.js";
import User from "../models/User.js";
import { challengeStore } from "../stores/challenge.store.js";

/**
 * Socket events:
 * - challenge:send { toUserId } (ack)
 * - challenge:accept { challengeId } (ack) => returns matchId
 * - challenge:decline { challengeId } (ack)
 *
 * Emits to target:
 * - challenge:incoming { challenge }
 * - challenge:updated  { challenge }
 * - challenge:match_ready { matchId, match }
 */
export function bindChallengeSockets(io, { matchmakingService } = {}) {
  io.on("connection", (socket) => {
    const myUserId = socket?.data?.user?.userId || null;

    socket.on("challenge:send", async (payload, ack) => {
      try {
        if (!myUserId) throw createError(401, "Unauthorized (guest)");

        const toUserId = payload?.toUserId?.toString?.().trim();
        if (!toUserId) throw createError(400, "Missing toUserId");
        if (toUserId === myUserId) throw createError(400, "Cannot challenge yourself");

        // Optional: ensure target exists
        const target = await User.findById(toUserId).select("_id").lean();
        if (!target) throw createError(404, "Target user not found");

        const challenge = challengeStore.create({
          fromUserId: myUserId,
          toUserId,
        });

        // Notify target
        io.to(`user:${toUserId}`).emit("challenge:incoming", { challenge });

        if (typeof ack === "function") ack({ ok: true, challenge });
      } catch (err) {
        if (typeof ack === "function")
          ack({ ok: false, message: err?.message || "Failed to send challenge" });
      }
    });

    socket.on("challenge:decline", async (payload, ack) => {
      try {
        if (!myUserId) throw createError(401, "Unauthorized (guest)");

        const challengeId = payload?.challengeId?.toString?.().trim();
        if (!challengeId) throw createError(400, "Missing challengeId");

        const c = challengeStore.get(challengeId);
        if (!c) throw createError(404, "Challenge not found");

        if (c.toUserId !== myUserId) throw createError(403, "Not your challenge");
        if (c.status !== "pending") throw createError(400, "Challenge is not pending");

        const updated = challengeStore.updateStatus(challengeId, "declined");

        io.to(`user:${c.fromUserId}`).emit("challenge:updated", { challenge: updated });
        io.to(`user:${c.toUserId}`).emit("challenge:updated", { challenge: updated });

        if (typeof ack === "function") ack({ ok: true, challenge: updated });
      } catch (err) {
        if (typeof ack === "function")
          ack({ ok: false, message: err?.message || "Failed to decline" });
      }
    });

    socket.on("challenge:accept", async (payload, ack) => {
      try {
        if (!myUserId) throw createError(401, "Unauthorized (guest)");

        const challengeId = payload?.challengeId?.toString?.().trim();
        if (!challengeId) throw createError(400, "Missing challengeId");

        const c = challengeStore.get(challengeId);
        if (!c) throw createError(404, "Challenge not found");

        if (c.toUserId !== myUserId) throw createError(403, "Not your challenge");
        if (c.status !== "pending") throw createError(400, "Challenge is not pending");

        const updated = challengeStore.updateStatus(challengeId, "accepted");

        // ✅ Create a match in DB (so both sides share a matchId)
        const match = await Match.create({
          gameMode: "1v1",
          region: "global",
          status: "pending",
          players: [
            { userId: c.fromUserId, team: "red", connected: true, ready: true },
            { userId: c.toUserId, team: "blue", connected: true, ready: true },
          ],
          settings: { maxPlayers: 2, duration: 600, isRanked: false, allowSpectators: false },
        });

        const matchId = match.matchId;

        // Notify both players
        io.to(`user:${c.fromUserId}`).emit("challenge:match_ready", {
          matchId,
          match,
          challenge: updated,
        });
        io.to(`user:${c.toUserId}`).emit("challenge:match_ready", {
          matchId,
          match,
          challenge: updated,
        });

        if (typeof ack === "function") ack({ ok: true, matchId, match, challenge: updated });
      } catch (err) {
        if (typeof ack === "function")
          ack({ ok: false, message: err?.message || "Failed to accept" });
      }
    });
  });
}
