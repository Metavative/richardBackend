// src/stores/presence.store.js
/**
 * Presence store (in-memory):
 * - userId -> { sockets: Set<string>, lastSeenAt: number }
 */
class PresenceStore {
  constructor() {
    this.map = new Map();
  }

  upsert(userId, socketId) {
    if (!userId) return;
    const now = Date.now();
    const existing = this.map.get(userId);

    if (!existing) {
      this.map.set(userId, { sockets: new Set([socketId]), lastSeenAt: now });
      return;
    }

    existing.sockets.add(socketId);
    existing.lastSeenAt = now;
  }

  removeSocket(userId, socketId) {
    if (!userId) return { becameOffline: false };
    const existing = this.map.get(userId);
    if (!existing) return { becameOffline: false };

    existing.sockets.delete(socketId);
    existing.lastSeenAt = Date.now();

    if (existing.sockets.size === 0) {
      this.map.delete(userId);
      return { becameOffline: true };
    }

    return { becameOffline: false };
  }

  isOnline(userId) {
    return this.map.has(userId);
  }

  getOnlineUserIds() {
    return Array.from(this.map.keys());
  }

  snapshot() {
    return Array.from(this.map.entries()).map(([userId, v]) => ({
      userId,
      lastSeenAt: v.lastSeenAt,
      socketCount: v.sockets.size,
    }));
  }
}

export const presenceStore = new PresenceStore();
