// src/stores/challenge.store.js
import crypto from "crypto";

/**
 * In-memory challenges:
 * challengeId -> {
 *   id, fromUserId, toUserId, status, createdAt
 * }
 */
class ChallengeStore {
  constructor() {
    this.map = new Map();
  }

  create({ fromUserId, toUserId }) {
    const id = crypto.randomBytes(10).toString("hex");
    const c = {
      id,
      fromUserId,
      toUserId,
      status: "pending", // pending | accepted | declined | cancelled
      createdAt: Date.now(),
    };
    this.map.set(id, c);
    return c;
  }

  get(id) {
    return this.map.get(id) || null;
  }

  updateStatus(id, status) {
    const c = this.map.get(id);
    if (!c) return null;
    c.status = status;
    this.map.set(id, c);
    return c;
  }

  delete(id) {
    this.map.delete(id);
  }
}

export const challengeStore = new ChallengeStore();
